function display(){
    var a=document.getElementById("namesunrname").value;
    if(a!=null){
        document.getElementById("genemail").innerHTML=a+"@gmail.com";
        document.getElementById("genemail").style.display="block";
        document.getElementById("account").style.display="block";
        document.getElementById("noaccount").style.display="none";
    }
    if(a==""){
        document.getElementById("genemail").innerHTML="No Input from user";
        document.getElementById("genemail").style.display="block";
        document.getElementById("noaccount").style.display="block";
        document.getElementById("account").style.display="none";
    }
}