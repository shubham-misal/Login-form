function displaylogin(){
    var a=document.getElementById("namesunrname").value;
    switch(a){
        case "shubhamm10@gmail.com":a="Hey, <i>Shubham </i>Welcome to Gmail";
        break;
        case "SHUBHAMM10@GMAIL.COM":a="Hey, <i>Shubham </i>Welcome to Gmail";
        break;

        case "shubhammisal200003@gmail.com":a="Hey, <i>Shubham</i> Welcome to Gmail";
        break;
        case "SHUBHAMMISAL200003@GMAIL.COM":a="Hey, <i>Shubham</i> Welcome to Gmail";
        break;

        case "misalshubham2021@gmail.com":a="Hey, <i>Shubham</i> Welcome to Gmail";
        break;
        case "MISALSHUBHAM2021@GMAIL.COM":a="Hey, <i>Shubham</i> Welcome to Gmail";
        break;

        case "shubhaM20@gmail.com":a="Hey, <i>Shubham </i> Welcome to Gmail";
        break;
        case "SHUBHAM20@GMAIL.COM":a="Hey, <i>Shubham </i> Welcome to Gmail";
        break;

        case "shubham67@gmail.com":a="Hey, <i>Shubham </i> Welcome to Gmail";
        break;
        case "SHUBHAM67@GMAIL.COM":a="Hey, <i>Shubham </i> Welcome to Gmail";
        break;

        case "shubhaM20271110@gmail.com":a="Hey,<i>Shubham </i> Welcome to Gmail";
        break;
        case "SHUBHAM20271110@GMAIL.COM":a="Hey,<i>Shubham </i> Welcome to Gmail";
        break;

        case "shubham22710@gmail.com":a="Hey, <i>Shubham </i> Welcome to Gmail";
        break;
        case "SHUBHAM22710@GMAIL.COM":a="Hey, <i>Shubham </i> Welcome to Gmail";
        break;

        case"pawarrishikesh5300@gmail.com":a="Hey <i>Rishikesh</i> Welcome to Gmail";
        break;
        case"PAWARRISHIKESH5300@gmail.com":a="Hey <i>Rishikesh</i> Welcome to Gmail";
        break;
        
        case"abcd@gmail.com":a="Hey User Welcome to Javascript";
            break;
        case"ABCD@GMAIL.COM":a="Hey User Welcome to Javascript";
            break;
            
        case "":a="No Input (Email Address) from User";
        break;
        default:a=a+" <br> This Account doesn't EXISTS";
    }
    document.getElementById("genemail").innerHTML=a;
    document.getElementById("genemail").style.display="block";
}

